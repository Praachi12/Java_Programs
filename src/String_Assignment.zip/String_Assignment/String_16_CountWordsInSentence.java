package String_Assignment;

public class String_16_CountWordsInSentence {
    public static void main(String[] args) {
        String x= "We are proud Indians";
        String y[]= x.split(" ");
        System.out.println(y.length);
    }
}
