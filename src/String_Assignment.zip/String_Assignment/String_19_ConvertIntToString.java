package String_Assignment;

public class String_19_ConvertIntToString {
    public static void main(String[] args) {
        {
            int x= 65;
            String y = Integer.toString(x);
            System.out.println(x);
            System.out.println(y);
        }
    }
}
