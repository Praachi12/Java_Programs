package String_Assignment;

public class String_12_CheckStringIsEmptyOrNot
{
    public static void main(String[] args) {
        String s = " ABC";
        if(s.length()== 0 )
        {
            System.out.println("String is empty");
        }
        else
            System.out.println("String is not empty");
    }
}
