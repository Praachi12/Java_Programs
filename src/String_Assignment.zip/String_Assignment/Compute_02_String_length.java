package String_Assignment;

public class Compute_02_String_length {
    public static void main(String[] args) {
        String x = "ABC tech";
        System.out.println("Computing String length using built in method");
        System.out.println(x.length());
    }
}
