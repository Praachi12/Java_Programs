package String_Assignment;

public class String_20_ConvertStringToInt {
    public static void main(String[] args) {
        String s = "65";
        int x = Integer.parseInt(s);
        System.out.println(s);
        System.out.println(x);
    }
}
