package String_Assignment;

public class String_13_ImmutableEx {
    public static void main(String[] args) {
        String x= "ABC";
        String y = "XYZ";
        x.concat(y);
        System.out.println(x);
    }
}
